import { computeDiff } from '../_shared/diff.ts';

// In-memory storage for versions (will be reset on function restart)
// In production, you would use a database for persistence
let versions: any[] = [];
let previousContent = "";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { content } = await req.json();
    
    if (!content || typeof content !== 'string') {
      return new Response(
        JSON.stringify({ error: 'Content is required and must be a string' }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        },
      );
    }

    console.log('POST /save-version - Saving new version');
    console.log('Previous content length:', previousContent.length);
    console.log('New content length:', content.length);

    // Compute diff using custom word-level algorithm
    const diffResult = computeDiff(previousContent, content);

    // Generate UUID (simple implementation for Deno)
    const id = crypto.randomUUID();
    const timestamp = new Date().toISOString();

    // Create new version object
    const newVersion = {
      id,
      timestamp,
      addedWords: diffResult.addedWords,
      removedWords: diffResult.removedWords,
      oldLength: diffResult.oldLength,
      newLength: diffResult.newLength,
    };

    // Add to versions array
    versions.push(newVersion);
    
    // Update previous content for next comparison
    previousContent = content;

    console.log('Version saved successfully:', id);
    console.log('Total versions:', versions.length);

    return new Response(
      JSON.stringify(newVersion),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    );
  } catch (error) {
    console.error('Error in save-version function:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    );
  }
});
