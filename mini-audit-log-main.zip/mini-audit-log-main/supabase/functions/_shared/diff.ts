/**
 * Custom word-level diff computation function
 * 
 * Compares two text strings and identifies added/removed words.
 * 
 * @param oldText - The previous content
 * @param newText - The new content
 * @returns Object containing diff results with actual word changes
 */
export function computeDiff(
  oldText: string,
  newText: string
): {
  addedWords: string[];
  removedWords: string[];
  oldLength: number;
  newLength: number;
} {
  const oldWords = oldText
    ? oldText.trim().toLowerCase().split(/\s+/).filter(w => w.length > 0)
    : [];
  const newWords = newText
    ? newText.trim().toLowerCase().split(/\s+/).filter(w => w.length > 0)
    : [];

  const addedWords = newWords.filter(w => !oldWords.includes(w));
  const removedWords = oldWords.filter(w => !newWords.includes(w));

  return {
    addedWords,
    removedWords,
    oldLength: oldWords.length,
    newLength: newWords.length,
  };
}
