import { useState, useEffect } from "react";
import { Save, CheckCircle2, Edit3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface EditorProps {
  content: string;
  onContentChange: (content: string) => void;
  onSave: () => void;
  isLoading: boolean;
}

export const Editor = ({ content, onContentChange, onSave, isLoading }: EditorProps) => {
  const [isSaved, setIsSaved] = useState(true);

  useEffect(() => {
    setIsSaved(false);
    const timer = setTimeout(() => {
      setIsSaved(true);
    }, 1000);
    return () => clearTimeout(timer);
  }, [content]);

  const wordCount = content.trim() ? content.trim().split(/\s+/).filter(w => w.length > 0).length : 0;
  const charCount = content.length;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-border p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Edit3 className="w-5 h-5 text-muted-foreground" />
          <h2 className="text-lg font-semibold text-foreground">Current Document Editor</h2>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-4 text-sm text-muted-foreground">
            <span>{wordCount} words</span>
            <span>•</span>
            <span>{charCount} characters</span>
            <span>•</span>
            <div className="flex items-center gap-1">
              {isSaved ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span className="text-green-600">Saved</span>
                </>
              ) : (
                <span className="text-amber-600">Editing...</span>
              )}
            </div>
          </div>
          
          <Button
            onClick={onSave}
            disabled={isLoading}
            className="rounded-full px-6 shadow-sm transition-all duration-200 hover:shadow-md"
            size="default"
          >
            <Save className="w-4 h-4 mr-2" />
            {isLoading ? 'Saving...' : 'Save Version'}
          </Button>
        </div>
      </div>

      <Textarea
        value={content}
        onChange={(e) => onContentChange(e.target.value)}
        placeholder="Start typing your document here..."
        className="w-full min-h-[300px] p-4 rounded-lg border-2 focus:ring-2 focus:ring-primary/20 transition-all duration-200 font-mono text-sm resize-none"
      />

      <div className="flex sm:hidden items-center gap-3 text-sm text-muted-foreground pt-2">
        <span>{wordCount} words</span>
        <span>•</span>
        <span>{charCount} chars</span>
        <span>•</span>
        <div className="flex items-center gap-1">
          {isSaved ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              <span className="text-green-600">Saved</span>
            </>
          ) : (
            <span className="text-amber-600">Editing...</span>
          )}
        </div>
      </div>
    </div>
  );
};
