import { History, FileStack } from "lucide-react";
import { VersionCard } from "./VersionCard";

interface Version {
  id: string;
  timestamp: string;
  addedWords: string[];
  removedWords: string[];
  oldLength: number;
  newLength: number;
}

interface VersionListProps {
  versions: Version[];
}

export const VersionList = ({ versions }: VersionListProps) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-border p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-muted-foreground" />
          <h2 className="text-lg font-semibold text-foreground">Version History</h2>
        </div>
        
        {versions.length > 0 && (
          <span className="px-3 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full">
            {versions.length} version{versions.length === 1 ? '' : 's'}
          </span>
        )}
      </div>

      {versions.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="flex items-center justify-center w-16 h-16 mb-4 bg-muted/30 rounded-full">
            <FileStack className="w-8 h-8 text-muted-foreground" />
          </div>
          <p className="text-base font-medium text-muted-foreground mb-1">No versions yet</p>
          <p className="text-sm text-muted-foreground/70">Save your first version to start tracking changes</p>
        </div>
      ) : (
        <div className="space-y-3">
          {versions.map((version, index) => (
            <VersionCard
              key={version.id}
              version={version}
              index={index}
            />
          ))}
        </div>
      )}
    </div>
  );
};
