import { History, FileText, Settings, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Navbar = () => {
  return (
    <nav className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 bg-white border-b border-border shadow-sm">
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-lg">
          <FileText className="w-5 h-5 text-primary" />
        </div>
        <h1 className="text-lg font-semibold text-foreground">Smart Version Tracker</h1>
      </div>

      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" className="gap-2">
          <History className="w-4 h-4" />
          <span className="hidden sm:inline">History</span>
        </Button>
        <Button variant="ghost" size="sm" className="gap-2">
          <Settings className="w-4 h-4" />
          <span className="hidden sm:inline">Settings</span>
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full">
          <User className="w-4 h-4" />
        </Button>
      </div>
    </nav>
  );
};
