import { Badge } from "@/components/ui/badge";
import { Plus, Minus } from "lucide-react";

interface DiffBadgeProps {
  type: 'added' | 'removed';
  count: number;
  words: string[];
  expanded?: boolean;
}

export const DiffBadge = ({ type, count, words, expanded = false }: DiffBadgeProps) => {
  if (count === 0) return null;

  const isAdded = type === 'added';
  
  return (
    <div className="space-y-2">
      <Badge 
        className={`
          px-3 py-1 text-xs font-medium rounded-full transition-all duration-200
          ${isAdded 
            ? 'bg-green-100 text-green-700 border-green-200 hover:bg-green-200' 
            : 'bg-red-100 text-red-700 border-red-200 hover:bg-red-200'
          }
        `}
      >
        {isAdded ? (
          <Plus className="w-3 h-3 mr-1 inline" />
        ) : (
          <Minus className="w-3 h-3 mr-1 inline" />
        )}
        {count} {isAdded ? 'added' : 'removed'}
      </Badge>
      
      {expanded && words.length > 0 && (
        <div className="pl-2">
          <div className="flex flex-wrap gap-1">
            {words.map((word, idx) => (
              <span
                key={idx}
                className={`
                  px-2 py-0.5 text-xs rounded
                  ${isAdded 
                    ? 'bg-green-50 text-green-800 border border-green-200' 
                    : 'bg-red-50 text-red-800 border border-red-200 line-through'
                  }
                `}
              >
                {word}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
