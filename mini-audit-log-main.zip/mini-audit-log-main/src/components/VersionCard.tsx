import { useState } from "react";
import { Clock, ChevronDown, ChevronUp, ArrowRight } from "lucide-react";
import { Card } from "@/components/ui/card";
import { DiffBadge } from "./DiffBadge";
import { formatDistanceToNow } from "date-fns";

interface Version {
  id: string;
  timestamp: string;
  addedWords: string[];
  removedWords: string[];
  oldLength: number;
  newLength: number;
}

interface VersionCardProps {
  version: Version;
  index: number;
}

export const VersionCard = ({ version, index }: VersionCardProps) => {
  const [expanded, setExpanded] = useState(false);
  
  const timeAgo = formatDistanceToNow(new Date(version.timestamp), { addSuffix: true });

  return (
    <Card 
      className="bg-white rounded-xl p-4 border border-border shadow-sm hover:shadow-md transition-all duration-200 animate-in fade-in slide-in-from-bottom-2"
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <div className="space-y-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span className="font-medium">{timeAgo}</span>
              <span className="text-xs font-mono bg-muted px-2 py-0.5 rounded">
                {version.id.slice(0, 8)}
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              <DiffBadge 
                type="added" 
                count={version.addedWords.length} 
                words={version.addedWords}
                expanded={expanded}
              />
              <DiffBadge 
                type="removed" 
                count={version.removedWords.length} 
                words={version.removedWords}
                expanded={expanded}
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 text-sm font-mono text-muted-foreground whitespace-nowrap">
              <span className="font-semibold">{version.oldLength}</span>
              <ArrowRight className="w-4 h-4 text-primary" />
              <span className="font-semibold text-foreground">{version.newLength}</span>
              <span className="text-xs">words</span>
            </div>
          </div>
        </div>

        {(version.addedWords.length > 0 || version.removedWords.length > 0) && (
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1 text-xs text-primary hover:text-primary/80 transition-colors duration-200 font-medium"
          >
            {expanded ? (
              <>
                <ChevronUp className="w-3 h-3" />
                Hide details
              </>
            ) : (
              <>
                <ChevronDown className="w-3 h-3" />
                Show details
              </>
            )}
          </button>
        )}
      </div>
    </Card>
  );
};
