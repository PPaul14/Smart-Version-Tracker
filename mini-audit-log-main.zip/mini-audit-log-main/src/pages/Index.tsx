import { useState, useEffect } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Editor } from "@/components/Editor";
import { VersionList } from "@/components/VersionList";

interface Version {
  id: string;
  timestamp: string;
  addedWords: string[];
  removedWords: string[];
  oldLength: number;
  newLength: number;
}

const Index = () => {
  const [content, setContent] = useState("");
  const [versions, setVersions] = useState<Version[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Load versions on mount
  useEffect(() => {
    loadVersions();
  }, []);

  const loadVersions = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('versions', {
        method: 'GET',
      });

      if (error) throw error;
      setVersions(data || []);
    } catch (error) {
      console.error('Error loading versions:', error);
      toast.error('Failed to load version history');
    }
  };

  const saveVersion = async () => {
    if (!content.trim()) {
      toast.error('Content cannot be empty');
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('save-version', {
        body: { content },
      });

      if (error) throw error;

      setVersions(prev => [data, ...prev]);
      toast.success('Version saved successfully');
    } catch (error) {
      console.error('Error saving version:', error);
      toast.error('Failed to save version');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto p-4 md:p-8 space-y-6">
        <Editor
          content={content}
          onContentChange={setContent}
          onSave={saveVersion}
          isLoading={isLoading}
        />
        
        <VersionList versions={versions} />
      </main>
    </div>
  );
};

export default Index;
